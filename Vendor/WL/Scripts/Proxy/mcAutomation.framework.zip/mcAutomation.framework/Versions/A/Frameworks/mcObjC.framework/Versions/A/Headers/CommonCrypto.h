//
//  CommonCrypto.h
//  mcCore
//
//  Created by VG (DE) on 18/02/2017.
//  Copyright © 2017 WaveLabs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommonCrypto: NSObject

+ (nonnull NSString *)md5Hash:(nonnull NSString *)input;

@end
